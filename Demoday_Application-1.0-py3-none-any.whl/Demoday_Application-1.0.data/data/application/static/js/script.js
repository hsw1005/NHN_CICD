function myFunction() {
    document.getElementById("demo").innerHTML = "javascript";
  }